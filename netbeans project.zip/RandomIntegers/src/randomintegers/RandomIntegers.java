
package randomintegers;

import java.security.SecureRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RandomIntegers {

    public static void main(String[] args) {
       SecureRandom randomNumbers = new SecureRandom();
       
       System.out.println("Random numbers on separate lines: ");
       randomNumbers.ints(50, 1, 999)
                    .forEach(System.out::println);
       
       String numbers = 
               randomNumbers.ints(50, 1, 999)
                            .mapToObj(String::valueOf)
                            .collect(Collectors.joining(" "));
       System.out.printf("%nRandom numbers on one line: %s%n", numbers);
       
       System.out.printf("Odds of the numbers are: %sd%n",
               IntStream.rangeClosed(1, 999)
               .filter(x -> x %3 == 0)
               .sorted()
       );
    }
    
}
