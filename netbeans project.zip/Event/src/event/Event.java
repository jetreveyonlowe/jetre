/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package event;

import java.util.Arrays;
import java.util.Locale;

/**
 *
 * @author Jlowe
 */
public class Event {

    public String eventDate = null;
    public String time = null;
    public String eventVenue = null;
    String [] attendees;
    private final Event event1;
    
    public String getEventDate(){ //method return eventDate variable.
            return eventDate;
        }
    public String getTime(){ // method to return time variable.
        return time;
    }
    public String getEventVenue(){ //method to return eventVenue variable.
        return eventVenue;
    }
    public String[] getAttendees(){ // method with enhanced forloop to run through object array.
        for (String attendee : attendees) {// Array type and array name.
            System.out.println(Arrays.toString(attendees));// wrapped array to print out list of array.
            return attendees;
        }
        return null;
    }
    public String showEventDetails(){ //method to show string representation of time ,Eventvene, and array.
       return String.format("%ntime of the event"  + getTime(),
                "%nThis is the the event venue" + getEventVenue(),
                "%nThese are the attendees" + Arrays.toString(getAttendees()));
    }
    public String displayTicketStats(){
        int ticketStats = 0;
        switch(ticketStats) {
                case 1: System.out.println("ticketPriced 0-$30:50(left)");
                    break;
                case 2: System.out.println("ticketPriced $30-$60:98(left)");
                    break;
                case 3: System.out.println("ticketPriced $60 and above:45(left)");
                    break;
                    default:
        }
        System.out.print(ticketStats);
        return null;
    }
    public String displayAttendeeStats(){
       int age = 0;
       int childAge = 0;
       int adultAge = 0;
       int seniorAge = 0; 
       
       switch(age) {
       case 1: if(attendees => 18){
           ++childAge;
           System.out.println("child atteendees:" + Attendant.getAge(attendees));
       break;
       case 2: System.out.println("adult attendees:45");
           break;
       case 3: System.out.println("senior attendees:23");
           break;
           default:
       }
       System.out.print(attendeeStats);
        return null;
    }
 public Event(String eventDate, String time, String eventVenue){//initializes objects in the constructor for the event.
this.event1 = new Event("10-20-2017", "9:00PM","Phillips arena");
this.eventDate = eventDate;
this.time = time;
this.eventVenue = eventVenue;
}
public static void main(String[]args){
        event1.getToString();
}
    public String getToString(){
    return String.format("%nThis is the attendees attending the event:" + Arrays.toString(event1.getAttendees()),
            "%nThis is the event details:" + event1.showEventDetails(),
            "%nThis is the ticketStats:" + event1.displayTicketStats(),
            "%nThis is the attendeeStats:" + event1.displayAttendeeStats());
    } 
   
    }
}



