/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangle;

import java.util.Scanner;

/**
 *
 * @author Jlowe
 */
public class Rectangle {

    public float length = 1;
    public float width = 1;
    public float perimeter;
    public float area;
    
    public Rectangle(float length, float width){
        this.length = length;
        this.width = width;
    }

   
    public float getLength(){
        return length ;
    }

    public void setLength(float length) {
        this.length = length;
        
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
       this.width = width;
        
    }
  
    
   

   public float getPerimeter(){
       Scanner input = new Scanner(System.in);
       System.out.println("Enter length:");
       input.nextFloat();
       System.out.println("Enter width:");
       input.nextFloat();
       perimeter = (2 * length) + (2 * width);
       System.out.println("perimeter calculated:");
       return perimeter;
}
public float getArea(){
Scanner input = new Scanner (System.in);
System.out.println("Enter length:");
input.nextFloat();
System.out.println("Enter width:");
input.nextFloat();
area = length * width ; 
return area;
}

public String getToString(){
 return String.format("%nArea:" + getArea(),"%nPerimeter" + getPerimeter());
}
}



   