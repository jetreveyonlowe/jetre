
package rectangle;

/**
 *
 * @author Jlowe
 */
public class RectangleTest extends Rectangle{
    
public static void main(String[]args){
    

}

    public RectangleTest(float length, float width) {
        super(length, width);
    }
    
    
@Override
     public String getToString(){
 return String.format("%nArea:" + getArea(),"%nPerimeter" + getPerimeter());
    
}
}     


   


 
