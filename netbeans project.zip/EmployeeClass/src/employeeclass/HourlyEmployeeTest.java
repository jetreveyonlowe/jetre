/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeclass;

public class HourlyEmployeeTest{
    
   
    public static void main(String[] args) {
        
        HourlyEmployee employee1 = new HourlyEmployee("tre", "Lowe", 678-78-8987, 20, 9.50 );
        
        System.out.println(employee1.getToString());
    }
    }

