/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeclass;

/**
 *
 * @author student1212
 */
public class HourlyEmployee extends EmployeeClass {
    // instance variables.
    public int hours;
    public double wage;
    public double earnings;
    
    public HourlyEmployee(String firstName, String lastName, int socialSecurity, int hours, double wage) {
        super(firstName, lastName, socialSecurity);
        this.hours = hours;
        this.wage = wage;
        
    }

    
        // ensure that the hours are between 0 and 168.
    public void setHours(int hours){
        if (hours > 168) {
            throw new IllegalArgumentException("hours must be between 0 and 168");
        }
        this.hours = hours;
    }
    
    public int getHours(){
        return hours;
    }
    // ensure the wage is not a negative.
    public void setWage (double wage){
        if (wage < 0){
            throw new IllegalArgumentException("wage must be above 0.0");
                   } else {
             this.wage = wage;
        }
                   
    }
    
    public double getWage(){
        return wage;
    }

    public double getEarnings(){
    earnings = hours * wage; 
        return earnings;
    }
    
    //method to display all instance variables in string formatting.
    @Override
    public String getToString(){
        return String.format("This is employee's information:" + "%nFirstname:" + getFirstName() +
                "%nlastName:" + getLastName() +
                "%nsocialSecurity:" + getSocialSecurity() + 
                "%nhours:" + getHours() +
                "%nwage:" + getWage() +
                "%nearnings:" + getEarnings());
    }
}