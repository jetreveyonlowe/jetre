/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeclass;

/**
 *
 * @author student1212
 */
public class EmployeeClass {
    
    public String firstName;
    public String lastName;
    public int socialSecurity;
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public int getSocialSecurity(){
        return socialSecurity;
    }
    

    public String getToString(){
    return String.format("Firstname:"+ getFirstName(), "lastName" + getLastName(), "socialSecurity" + getSocialSecurity());    
    }

    public EmployeeClass(String firstName, String lastName, int socialSecurity ){
        
        this.lastName = lastName;
        this.socialSecurity = socialSecurity;
    }
        
}


