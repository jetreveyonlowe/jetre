/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Jlowe
 */
public class EmployeeTest extends Employee {

    public EmployeeTest(String firstName, String lastName, String socialsecurityNumber, double grossSales, double commissionRate) {
        super(firstName, lastName, socialsecurityNumber, grossSales, commissionRate);
    }
    
    
    public static void main (String[]args){
    
   Employee employee1 = new Employee("tre", "lowe", "786-304-3040", 10000.00, 1.0);
     

    System.out.println(employee1.getToString());
    }
}

            