/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Jlowe
 */
public class Employee {
    
    public String firstName;
    public String lastName;
    public String socialsecurityNumber;
    public double grossSales;
    public double commissionRate;
    
 
    public Employee(String firstName, String lastName, String socialsecurityNumber, double grossSales, double commissionRate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialsecurityNumber = socialsecurityNumber;
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }
 
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public double getCommissionRate(){
        if (commissionRate < 0.0 ||  commissionRate > 1.0){
            throw new IllegalArgumentException(" CommissionRate must be between 0.0 and 1.0");
        }else 
            return commissionRate;
}

    public double getGrossSales(){
        if(grossSales < 0.0){
            throw new IllegalArgumentException("must be greater than 0.0");
        }else 
            return grossSales;
    }
    public String getSocialsecurityNumber(){
        return socialsecurityNumber;
    }
    public String getToString(){
        return String.format("firstName:" + getFirstName() + 
                "%nlastName:" + getLastName() +
                "%nsocialSecurityNumber:" + 
                getSocialsecurityNumber() + 
                "%ncommissionRate" + 
                getCommissionRate() +
                "%nGrossSales:" +
                getGrossSales());
}
}

 
