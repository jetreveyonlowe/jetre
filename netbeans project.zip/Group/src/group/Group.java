/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package group;

/**
 *
 * @author Jlowe
 */
public class Group {
   private String [] accessTypeAdmin;
   private String [] accessTypeProject;
}  
public static void main(String[] args){
    
    
public boolean powerUser(){
String name = null;
Scanner myscanner = new Scanner(System.in);
System.out.println("Enter name here:");
.hasNextString();
