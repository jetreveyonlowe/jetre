/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jlowe
 */
public class EmployeeTest extends BasePlusCommissionCompensationModel {

    public EmployeeTest(String firstName, String lastName, int hours, double wage, double grossSales, double commissionRate) {
        super(firstName, lastName, hours, wage, grossSales, commissionRate);
    }
    
    
    SalariedCompensationModel emp = new SalariedCompensationModel("tre", "lowe", 40, 11);
    HourlyCompensation emp1 = new    HourlyCompensation("mary", "Jane", 45, 9.50);
    CommissionCompensationModel emp2 = new CommissionCompensationModel("Luther", "Stewart", 40, 10 );
    BasePlusCommissionCompensationModel emp3 = new BasePlusCommissionCompensationModel("ruger", "luger", 40, 15, 20000.00, .3);
        
 