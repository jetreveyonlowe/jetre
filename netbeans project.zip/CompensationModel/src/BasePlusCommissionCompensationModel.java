/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jlowe
 */
public class BasePlusCommissionCompensationModel implements CompensationModel {
    public double grossSales;
    public double commissionRate;
    public double baseSalary;
    
    @Override
    public double earnings(){
    double earnings = baseSalary + grossSales * commissionRate;
    return earnings;
    }
    
    @Override 
    public String toString(){
        return String.format("employees who are paid a baseSalary snd commission" + earnings());
    }
    
}
