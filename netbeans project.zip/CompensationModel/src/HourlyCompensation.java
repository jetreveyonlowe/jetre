/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jlowe
 */
public class HourlyCompensation extends SalariedCompensationModel implements CompensationModel {
    
    public int hour;
    public double Employeewage;

    public HourlyCompensation(String firstName, String lastName, int hours, double wage) {
        super(firstName, lastName, hours, wage);
    }
    
       
   public String getFirstName(){
       return firstName;
   }
   public String getLastName(){
       return lastName;
   }
   public int getHours(){
       return hours;
   }
    
   @Override 
   public double earnings(){
    double earnings = hours * wage;
    if (hours > 40 ){
      double overtime = hours * 1.5 * wage;
        return overtime; 
    }else { 
      return earnings;
    }
   }
    
    @Override
    public String toString() {
       return String.format("%nearnings for employees who worked",
               "%nfirstName:" + getFirstName(),
                "%nlastName" + getLastName(), 
                "%nhours" + getHours(),
                "%nearnings" + earnings());
}
}
