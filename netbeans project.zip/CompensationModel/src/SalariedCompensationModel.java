/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jlowe
 */
public class SalariedCompensationModel implements CompensationModel {
    
    public String firstName;
    public String lastName;
    public int hours;
    public double wage;
    public double weeklySalary;
    
   public SalariedCompensationModel(String firstName, String lastName, int hours, double wage){
       this.firstName = firstName;
       this.lastName = lastName;
       this.hours = hours;
       this.wage = wage;
   }
   
   public String getFirstName(){
       return firstName;
   }
   public String getLastName(){
       return lastName;
   }
   public int getHours(){
       return hours;
   }
    
    @Override
    public double earnings(){
        weeklySalary = hours * wage;
        return weeklySalary;
    }
    @Override
   public String toString(){
        return String.format("fixed employee weekly salary",
                "%nfirstName:" + getFirstName(),
                "%nlastName" + getLastName(), 
                "%nhours" + getHours(),
                "%nearnings" + earnings());
    }
    }


   
 
