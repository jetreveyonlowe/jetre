/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jlowe
 */
public class CommissionCompensationModel extends HourlyCompensation implements CompensationModel {

    double grossSales;
    double commissionRate;
    public CommissionCompensationModel(String firstName, String lastName, int hours, double wage,
    double grossSales,double commissionRate) {
        super(firstName, lastName, hours, wage);
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }
    
    /*@Override
    public double earnings(){
    double earnings = grossSales * commissionRate;
    return earnings;
    */
    @Override
    public double earnings(){
        return grossSales * commissionRate;
    }
    
    @Override
    public String toString(){
        return String.format("employee paid by commission:",
               "%nfirstName:" + getFirstName(),
                "%nlastName" + getLastName(), 
                "%nhours" + getHours(),
                "%nearnings" + earnings());
    }
    
    
}
