/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compensationmodel;

/**
 *
 * @author Jlowe
 */
public class CommissionCompensationModel extends HourlyCompensationModel implements CompensationModel {

    public double grossSales;
    public double commissionRate;
    
    public CommissionCompensationModel(String firstName, String lastName, String socialSecurity, int hours, double wage, double grossSales, double commissionRate) {
        super(firstName, lastName, socialSecurity, hours, wage);
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }

    /**
     *
     * @return
     */
    @Override
    public double getEarnings(){
        double earnings = grossSales * commissionRate;
        return earnings;
    }
    
    @Override
     public  String toString(){
     return String.format("FirstName:" + getFirstName(), "%nlastName:" + getLastName(),
            "%nsocialSecurity:" + getSocialSecurity(), "%nHours" + getHours(), 
            "%nOvertimeEarning:" + getEarnings());
    }
        
    }

