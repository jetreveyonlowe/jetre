/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compensationmodel;

/**
 *
 * @author Jlowe
 */
public class SalariedCompensationModel implements CompensationModel{
    
    public double weeklySalary;
    public String firstName;
    public String lastName;
    public String socialSecurity;
    public float hours;
    public double wage; 
    
    public SalariedCompensationModel (String firstName, String lastName, String socialSecurity){
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurity = socialSecurity;
    }
   
    public String getFirstName(){
        return firstName;
    }   
    public String getLastName(){
        return lastName;
    }
        
    public String getSocialSecurity(){
        return socialSecurity;
    }
    
    public double getWeeklySalary(){
    double weeklysalary = 5 *(hours * wage);
        return weeklySalary;
        
    }
    
    @Override
    public String toString(){
        return String.format("FirstName:" + getFirstName() ,"%nLastName:" + getLastName() , 
                "%nSocialSecurity:" + getSocialSecurity(), "n%Earnings:" + getEarnings(), 
                "%nWeeklySalary:" + getWeeklySalary());
    
    }

    
    @Override
    public double getEarnings() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double compensationModel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    }
    
    

                