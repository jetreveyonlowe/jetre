/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compensationmodel;


public class BaseplusCommissionCompensationModel extends CommissionCompensationModel implements CompensationModel { 
    
    public BaseplusCommissionCompensationModel(String firstName, String lastName, String socialSecurity, int hours, double wage, double grossSales, double commissionRate) {
        super(firstName, lastName, socialSecurity, hours, wage, grossSales, commissionRate);
    }
 
        CompensationModel [] employeeObjects = new CompensationModel[]{
        new SalariedCompensationModel("mary", "magdalen", "678-03-2039") ,
        new HourlyCompensationModel("jane", "kelly", "345-43-5665", 40, 9.50 ),
        new CommissionCompensationModel("bre", "lack", "343-34-3434", 45, 13.50, 10000.00, 1.0),
        new BaseplusCommissionCompensationModel("mike", "langly", "345-65-2323", 40,9.50, 10000.00, 1.0 )
    };
         System.out.println("Employees information:");
                                    
         for(BaseplusCommissionCompensationModel EmployeeObjects  : CompensationModel){
         BaseplusCommissionCompensationModel.toString(),
         BaseplusCommissionCompensationModel.getEarnings();
         
    }
}

         
    
