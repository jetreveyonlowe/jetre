/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compensationmodel;

/**
 *
 * @author Jlowe
 */
public class HourlyCompensationModel extends SalariedCompensationModel implements CompensationModel {

    public HourlyCompensationModel(String firstName, String lastName, String socialSecurity, int hours , double wage) {
        super(firstName, lastName, socialSecurity);
        this.wage = wage; 
        this.hours = hours;
    }
    
 public float getHours(){
     if (hours < 40){
     throw new IllegalArgumentException("Employee must have worked at least 40 hours to apply overtime");
     } else {
         return hours;
     }
 }
 
 public double getWage(){
     return wage;
 }
 
@Override
public double getEarnings(){
    double earnings = hours * 1.5 * wage;
    return earnings;
}

@Override 
public String toString(){
    return String.format("FirstName:" + getFirstName(), "%nlastName:" + getLastName(),
            "%nsocialSecurity:" + getSocialSecurity(), "%nHours" + getHours(), 
            "%nOvertimeEarning:" + getEarnings());
}
}