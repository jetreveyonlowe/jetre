/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package twelvedaysofchristmas;

import static java.lang.Character.UnicodeBlock.of;
import static java.util.EnumSet.of;
import static java.util.EnumSet.of;

public class TwelveDaysOfChristmas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[]args) {
    
    String day 1 = on the first day of christmas;
    String day 2 = on the second day of christmas;
    int day 3 =
        // TODO code application logic here
    }

}
