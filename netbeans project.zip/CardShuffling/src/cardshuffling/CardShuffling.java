/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardshuffling;

import javax.smartcardio.Card;

public class CardShuffling {

    private Card[] cards;
    private int topCardIndex = 52;

    public CardShuffling() {
        cards = new Card[52];
        int numberOfCard = 0;
        for(int suit = 0; suit <= 3; suit++){
            for(int value = 1; value <= 13; value++){
                cards[numberOfCard] 
                numberOfCard++;
            }
        }
        topCardIndex = 0;
    }

    public Card getCardAt(int position) {
        if (position >= cards.length - topCardIndex || position < topCardIndex) {
            throw new IndexOutOfBoundsException("Values are out of bounds");
        } else {
            return cards[topCardIndex + position];
        }
    }
 for(int index = 0; index < numCards; index ++) {
            drawnCards[index] = cards[topCard];
            topCard++;
        }
        return drawnCards;
    }
    public Card[] deal(int numCards) {
        // FIXME: check bounds, or make method "Card pickCardAt(int position)"
        // that removes the card from the deck
        Card[] drawnCards = new Card[numCards];

    }
    
}
