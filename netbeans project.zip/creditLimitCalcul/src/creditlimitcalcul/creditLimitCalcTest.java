
package creditlimitcalcul;




public class creditLimitCalcTest {

    /**
     
     * @param args
     */
    public static void main(String[]args) {
   
    creditlimitcalculator creditlimit1 = new creditlimitcalculator(4321, 500.43, .5 , 5000);
    
    System.out.printf("account number:%d%n", creditlimit1.getAccountNumber());
    System.out.printf("balance:%.2f%n", creditlimit1.getBalance());
    }
}
