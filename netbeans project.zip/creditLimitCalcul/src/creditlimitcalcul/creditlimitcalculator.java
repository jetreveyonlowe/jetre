package creditlimitcalcul;


public class creditlimitcalculator {
    
    private int accountNumber;
    private double balance;
    private double totalCharged;
    private int creditLimit;   
   
public creditlimitcalculator(int accountNumber, double balance, double totalCharged, int creditLimit){
    this.accountNumber = accountNumber;
    this.balance = balance;
    this.totalCharged = totalCharged;
    this.creditLimit = creditLimit; 
}
public void setAccountNumber(int accountNumber){
this.accountNumber = accountNumber;
}
public int getAccountNumber(){
return accountNumber;
    }
public void setBalance(double balance){
    this.balance = balance;
}
public double getBalance(){
    return balance;
}
public void setTotalcharged(double totalCharged){
    this.totalCharged = totalCharged;
}
public double getTotalCharged(){
if (balance > 1000) {
        balance = balance * 0.5;
    return totalCharged; }
        return balance;
}
public void setCreditLimit(int creditLimit){
    this.creditLimit = creditLimit;
}
public int getCreditLimit(){
    if (balance >= 5000){
       balance = -1 * balance;
       return (int) balance;
    }
     throw new IllegalArgumentException("you have exceeded your credit limit");
}
}

@Override 
public getToString(){
return String.format("CreditLimit:" + getCreditLimit(), "TotalCharged:" + getTotalCharged(),
"Balance" + getBalance(), "AccountNumber" + getAccountNumber());
}