/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package distance;

import java.util.Scanner;



public class Distance {
    
    double x1;
    double x2;
    double y1;
    double y2;
    public static double distance = 0;
    public static double distanceX = 0;
    public static double distanceY = 0;
    public static void main(String[] args) {
        // Scanner object to prompt user
    Scanner input = new Scanner(System.in);
    //prompt user for x1,x2,y1,y2 input
    System.out.println("enter x1:");
        double x1 = input.nextDouble();
    
     System.out.println("enter x2:");
     double x2 = input.nextDouble();
     
      System.out.println("enter y1:");
      double y1 = input.nextDouble();
       
      System.out.println("enter y2:");
      double y2 = input.nextDouble();
      
    System.out.println("distance calculated:" + getDistance(x1, x2, y1, y2));
   
       
    }
   // method to calculate and return distance value
    public static double getDistance(double x1, double x2, double y1, double y2) {
        distanceX = (x2 - x1 );
        distanceX=Math.pow(distanceX, 2);
        distanceY = (y2 - y1);
        distanceY = Math.pow(distanceY, 2);
        distance = distanceX + distanceY;
                
        return distance;
    }
}





