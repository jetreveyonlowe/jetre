/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import java.util.Scanner;

/**
 *
 * @author Jlowe
 */
public class Attendee {

    String name = null;
    double ticketPrice = -1;
    int age = -1;

    public Attendee(String name, double ticketPrice, int age){
        this.name = name;
        this.ticketPrice = ticketPrice;
        this.age = age;
    }
    public String getName(){
        return name;
    }
    public void setName(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter name:");
    }
    public double getTicketPrice(){
        return ticketPrice;
    }
    public void setTicketPrice(){
         Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Price:");
    }
    public int getAge(){
        return age;
    }
    public void setAge(){
         Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Age:");
        }
public String getToString(){
return String.format("Name:" + getName() + " " +
        "TicketPrice:" + getTicketPrice() + " " +
        "Age:" + getAge());
    }

public static void main(String[]args){
Attendee attendant2 = new Attendee("Mary Jane ", 15.34, 21);
System.out.println("This is the first attendant" + attendant2.getToString());

Attendee attendant1 = new Attendee("Tre Lowe", 17.23, 26);
        System.out.printf("this is the second attendant:" + attendant1.getToString());
}
}
