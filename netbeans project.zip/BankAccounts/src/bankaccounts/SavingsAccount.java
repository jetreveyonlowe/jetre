/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccounts;


public class SavingsAccount extends BankAccounts {
    
    private final double interestRate = 0.7;

    public SavingsAccount(String name, double balance, int accountNumber) {
        super(name, balance, accountNumber);
    }

    public double getInterestRate() {
        double balance1 = balance * interestRate;
        return interestRate;
    }
    @Override
    public String performHealthCheck(){
        return String.format("Balance of account:" + getBalance() + " " +
                "%nBalance of account with interestRate" + getInterestRate());
    }
}
