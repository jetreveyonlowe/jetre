/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccounts;

/**
 *
 * @author Jlowe
 */
public class BankAccounts {
     String name = null;
    private  int accountNumber = 0;
     double balance = 0;

    public BankAccounts(String name, double balance, int accountNumber){
        this.name = name;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }
    public String getName(){
    return name;
    }
    public int getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }
    public String performHealthCheck(){
        return String.format("Account name:" + getName() + " "
               + "%nAccountNumber for bankAccounts:" + getAccountNumber() + " "
                +  "%nHealthcheck invalid for this account.");
    }
    
}
       
       
        
