/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccounts;

/**
 *
 * @author Jlowe
 */
public class BankAccountManager extends BankAccounts{

  
    public BankAccountManager(String name, double balance, int accountNumber) {
        super(name, balance, accountNumber);
    }
    

    @Override
    public String getName() {
        return super.getName(); //To change body of generated methods, choose Tools | Templates.
    }
    BankAccountManager Caccount1 = new BankAccountManager("tre lowe", 1 , 2000);
    BankAccountManager Caccount2 = new BankAccountManager("mary jane", 2 , 3454.34);
            
}

