/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccounts;

public class checkingAccount extends BankAccounts {
        
    private final int minimumBalance = 0;
    private final int overdraftFee = 0;

    public checkingAccount(String name, double balance, int accountNumber) {
        super(name, balance, accountNumber);
    }

    public int getMinimumBalance() {
        if (getBalance() <= minimumBalance){
            System.out.println("Balance falls under minimum requirement, No depoits possible at this time ");
        }else if (getBalance() <= minimumBalance){
            System.out.println(getBalance());
        } 
        return 0;
    }    
    public int getOverdraftFee() {
        return overdraftFee;
    }
    @Override
    public String performHealthCheck(){
        return String.format("Checks balances of accountNumber:" + getMinimumBalance() +
        "%ncheckBalance:" + getBalance());
        
    }
}


    
