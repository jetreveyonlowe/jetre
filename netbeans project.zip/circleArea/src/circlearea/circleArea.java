

package circlearea;

import static java.lang.Math.PI;
import java.util.Scanner;

public class circleArea {

    public static float radius = 0;
    public static float circleArea= 0;
    public static void main(String[] args) {
        
    
        
        Scanner input = new Scanner(System.in);
        
    System.out.println("Enter the radius:");
    input.hasNextDouble();
    
    System.out.println("circleArea calculated:");

    
    public void getCircleArea(Float circleArea){
            
   
    
        
        

