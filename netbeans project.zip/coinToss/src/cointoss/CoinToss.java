/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cointoss;

import java.util.Scanner;

/**
 *
 * @author Jlowe
 */
import java.util.Random;


public class CoinToss {
    
public static void main(String[] args){    
}

private enum Coin{Heads, Tails};

Random randomNum = new Random();
private final int result = randomNum.nextInt(2);
private final int heads = 0;
private final int tails = 1;
Coin coinFlip ;

public void flip(){
    if(result == 0){
        coinFlip = Coin.Heads;
        System.out.println("You flipped Heads!");
    }else{
        coinFlip = Coin.Tails;
        System.out.println("You flipped Tails!");
    }
}
}



