/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg12daysofchristmas;

/**
 *
 * @author Jlowe
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       
        int day = 0;
        String oneDay = "on the first day of christmas my true love gave to me a Patridge in Pear Tree"; 
        String secondDay = "On the second day of christmas my true love gave to me2 Turtle Doves\n" +
"and a Partridge in a Pear Tree " ;
        String thirdDay = "On the third day of christmas" ;
        String FourthDay = "On the fourth day of christmas my true love gave to me 4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String fifthDay = "On the fifth day of Christmas\n" +
"my true love sent to me:\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String sixthDay = "On the sixth day of Christmas\n" +
"my true love sent to me:\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String seventhDay = "On the seventh day of Christmas\n" +
"my true love sent to me:\n" +
"7 Swans a Swimming\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String eighthDay = "On the eighth day of Christmas\n" +
"my true love sent to me:\n" +
"8 Maids a Milking\n" +
"7 Swans a Swimming\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String ninthDay = "On the ninth day of Christmas\n" +
"my true love sent to me:\n" +
"9 Ladies Dancing\n" +
"8 Maids a Milking\n" +
"7 Swans a Swimming\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String tenthDay = "On the tenth day of Christmas\n" +
"my true love sent to me:\n" +
"10 Lords a Leaping\n" +
"9 Ladies Dancing\n" +
"8 Maids a Milking\n" +
"7 Swans a Swimming\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree"; 
        String eleventhDay = "On the eleventh day of Christmas\n" +
"my true love sent to me:\n" +
"11 Pipers Piping\n" +
"10 Lords a Leaping\n" +
"9 Ladies Dancing\n" +
"8 Maids a Milking\n" +
"7 Swans a Swimming\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
        String twelfthDay = "On the twelfth day of Christmas\n" +
"my true love sent to me\n" +
"12 Drummers Drumming\n" + 
"11 Pipers Piping\n" +
"10 Lords a Leaping\n" +
"9 Ladies Dancing\n" +
"8 Maids a Milking\n" +
"7 Swans a Swimming\n" +
"6 Geese a Laying\n" +
"5 Golden Rings\n" +
"4 Calling Birds\n" +
"3 French Hens\n" +
"2 Turtle Doves\n" +
"and a Partridge in a Pear Tree";
    }
    
    int counter = 0;
    while (counter <= 14) {
               total += day ;
    }
    
}
