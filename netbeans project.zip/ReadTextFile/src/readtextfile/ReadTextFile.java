/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readtextfile;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * @author student1212
 */
public class ReadTextFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try(Scanner input = new Scanner (Paths.get("clients.xml"))){
            System.out.printf("%-10s%-12s%-12s%10s%n", "Account", "FirstName", 
                    "LastName", "Balance");
            while(input.hasNext()){
            System.out.printf("%-10d%-12s%-12s%10.2f%n", input.nextInt(),
                    input.next(), input.next(), input.nextDouble());
        }
    }
        catch(IOException | NoSuchElementException | IllegalStateException e){
            e.printStackTrace();
                }
    }
}
